#####################################################
# L2J GeoData                                       #
#####################################################
#                                                   #
# GeoData files should be unpacked inside:          #
# gameserver/data/geodata/                          #
#                                                   #
# More Info at:                                     #
# http://www.l2jserver.com/forum/viewforum.php?f=89 #
#                                                   #
#####################################################