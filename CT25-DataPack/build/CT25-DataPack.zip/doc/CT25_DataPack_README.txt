Copyright 2010-2013 BR Xtreme DataPack team

This file is part of the BR Xtreme DataPack.

BR Xtreme DataPack is free software; you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation; either version 3 of the License, or (at your option) any later 
version.

BR Xtreme DataPack is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with 
BR Xtreme DataPack; if not, write to the Free Software Foundation, Inc., 51 Franklin 
St, Fifth Floor, Boston, MA  02110-1301  USA


BR Xtreme Datapack SVN Build:  

Project Forum: http://brxtreme.forumexpress.org
Download: Our wiki contain directives for you to get the latest datapack 
revision either from nightly builds or via Subversion.

IRC: irc.freenode.net #l2j

BR Xtreme Datapack is *NOT* L2J. L2J is *NOT* BR Xtreme Datapack. Comments, questions, 
suggestions etc. should be directed to the appropriate forums.

Any given datapack copy you get, is designed/optimized to work with an specific 
BR Xtreme build. Ensure your core and datapack revisions match each other.

This readme assumes a basic understanding of MySQL commands and internals, SQL 
queries, or at least familiarity with a MySQL frontend. This readme will not 
teach you how to install MySQL nor will it teach you to use MySQL or any MySQL 
frontend. This readme is for the sole purpose of providing a brief overview of 
how to either install or upgrade the data in your database.


Installation:

All users: Copy all the datapack content to your gameserver directory/folder.
(for example C:\L2J\gameserver for Win users, /opt/l2j/gameserver for *nix)
You'd know if you are doing it right if you're being asked about overwriting
the data folder and/or its content, since L2J core includes a basic skeleton of
it. It's safe to answer 'yes' at this point.

For new BR Xtreme databases or existing databases where you want to delete character 
and account information: Create your loginserver and gameserver databases so they 
match the loginserver.properties and server.properties settings respectively (the 
default for both is 'dbgs'.)

Method 1: run database_installer.bat for windows users, or database_installer.sh for
linux/unix users.
Method 2: Select your database and run all the batch scripts in the sql folder

For existing BR Xtreme databases where you want to keep character and account 
information: 

Method 1: Run database_installer.bat for windows users, or 
database_installer.sh for linux/unix users. Choose (u)pgrade when asked.
Method 2: Select your database and run all the batch scripts in the 
sql folder that correspond to tables in your database that are missing or you 
want to upgrade.


IMPORTANT: 	There may also be changes altering table structures, if you need  such
an update after some certain changeset, you should run the relevant SQL sequence from
/sql/updates/. Database_installer tool will provide a way for you to execute them all.

-the BR Xtreme DataPack team

L2JDP, Copyright (C) 2010-2013 BR Xtreme DP comes with ABSOLUTELY NO WARRANTY. This is 
free software, and you are welcome to redistribute it under certain conditions.